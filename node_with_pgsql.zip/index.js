const pg = require('pg');
const pool = new pg.Pool({
  user: '<USER>',
  host: '127.0.0.1',
  database: 'online_vidya',
  password: '<PASSWORD>',
  port: '5432'
});

// pool.query("CREATE TABLE students(id SERIAL PRIMARY KEY, name VARCHAR(40) NOT NULL,email VARCHAR(40) NOT NULL, phone VARCHAR(40) NOT NULL, course VARCHAR(40) NOT NULL)", (err, res) => {
//   console.log(err, res);
//   pool.end();
// });

// pool.query("INSERT INTO students(id, name, email, phone, course) VALUES(1, 'Srinivas', 'srinivas@gmail.com', '1111111111', 'B.Tech')", (err, res) => {
//   console.log(err, res);
//   pool.end();
// });